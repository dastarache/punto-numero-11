class Calculadora:
    class Menu:
        @staticmethod
        def mostrar_menu():
            print("1. Triángulo")
            print("2. Cuadrado")
            print("3. Rectángulo")
            print("4. Rombo")
            print("5. Romboide")
            print("6. Trapecio")
            print("0. Salir")

        @staticmethod
        def obtener_opcion():
            return input("Seleccione una figura  o 0 para salir: ")

    def __init__(self):
        self._color = "Negro"  # Atributo protegido

    def calcular_area(self):
        pass

    def _metodo_privado(self):
        print("Este es un método privado")

class OperacionesMatematicas(Calculadora):
    def area(self, figura):
        return figura.calcular_area()

class Triangulo(Calculadora):
    def __init__(self, base, altura):
        super().__init__()
        self.base = base
        self.altura = altura

    def calcular_area(self):
        return (self.base * self.altura) / 2

class Cuadrado(Calculadora):
    def __init__(self, lado):
        super().__init__()
        self._lado = lado  # Atributo protegido

    def calcular_area(self):
        return self._lado ** 2

class Rectangulo(Calculadora):
    def __init__(self, base, altura):
        super().__init__()
        self.__base = base  # Atributo privado
        self.__altura = altura  # Atributo privado

    def calcular_area(self):
        return self.__base * self.__altura

class Rombo(Calculadora):
    def __init__(self, diagonal_mayor, diagonal_menor):
        super().__init__()
        self._diagonal_mayor = diagonal_mayor  # Atributo protegido
        self._diagonal_menor = diagonal_menor  # Atributo protegido

    def calcular_area(self):
        return (self._diagonal_mayor * self._diagonal_menor) / 2

class Romboide(Calculadora):
    def __init__(self, base, altura):
        super().__init__()
        self._base = base  # Atributo protegido
        self._altura = altura  # Atributo protegido

    def calcular_area(self):
        return self._base * self._altura

class Trapecio(Calculadora):
    def __init__(self, base_mayor, base_menor, altura):
        super().__init__()
        self._base_mayor = base_mayor  # Atributo protegido
        self._base_menor = base_menor  # Atributo protegido
        self._altura = altura  # Atributo protegido

    def calcular_area(self):
        return ((self._base_mayor + self._base_menor) * self._altura) / 2

def main():
    operaciones = OperacionesMatematicas()
    
    while True:
        Calculadora.Menu.mostrar_menu()
        opcion = Calculadora.Menu.obtener_opcion()
        if opcion == "0":
            print("¡Hasta luego!")
            break
        elif opcion == "1":
            base = float(input("Ingrese la base del triángulo: "))
            altura = float(input("Ingrese la altura del triángulo: "))
            figura = Triangulo(base, altura)
            print("El área del triángulo es:", operaciones.area(figura))
        elif opcion == "2":
            lado = float(input("Ingrese el lado del cuadrado: "))
            figura = Cuadrado(lado)
            print("El área del cuadrado es:", operaciones.area(figura))
        elif opcion == "3":
            base = float(input("Ingrese la base del rectángulo: "))
            altura = float(input("Ingrese la altura del rectángulo: "))
            figura = Rectangulo(base, altura)
            print("El área del rectángulo es:", operaciones.area(figura))
        elif opcion == "4":
            diagonal_mayor = float(input("Ingrese la longitud de la diagonal mayor del rombo: "))
            diagonal_menor = float(input("Ingrese la longitud de la diagonal menor del rombo: "))
            figura = Rombo(diagonal_mayor, diagonal_menor)
            print("El área del rombo es:", operaciones.area(figura))
        elif opcion == "5":
            base = float(input("Ingrese la base del romboide: "))
            altura = float(input("Ingrese la altura del romboide: "))
            figura = Romboide(base, altura)
            print("El área del romboide es:", operaciones.area(figura))
        elif opcion == "6":
            base_mayor = float(input("Ingrese la base mayor del trapecio: "))
            base_menor = float(input("Ingrese la base menor del trapecio: "))
            altura = float(input("Ingrese la altura del trapecio: "))
            figura = Trapecio(base_mayor, base_menor, altura)
            print("El área del trapecio es:", operaciones.area(figura))
        else:
            print("Opción no válida. Por favor, seleccione una opción válida.")

if __name__ == "__main__":
    main()
